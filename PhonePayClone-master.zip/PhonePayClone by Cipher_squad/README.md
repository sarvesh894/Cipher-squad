# PhonePayClone
PhonePe UI Clone Made for assignment of Google Udacity Scholarship. This is just a clone and not intented for Business Purposes

Made for Clone UI Challenege of Google Udacity Android Developer Scholarship Challenge 2018.

# Screencast Gif


![phonepay](https://user-images.githubusercontent.com/24228143/42137920-63135ef4-7d92-11e8-84e8-0d0bb00e28b6.gif)

# Screen shots


![home](https://user-images.githubusercontent.com/24228143/42137902-10d97a9c-7d92-11e8-93cf-665567c812e7.jpeg)
![offers](https://user-images.githubusercontent.com/24228143/42137903-110c6466-7d92-11e8-91b3-f401e1d38d17.jpeg)
![scan pay](https://user-images.githubusercontent.com/24228143/42137904-11413d80-7d92-11e8-9e98-f73eff19f499.jpeg)
![scan pays](https://user-images.githubusercontent.com/24228143/42137905-11740850-7d92-11e8-9839-cb6856a89d01.jpeg)
![transcation](https://user-images.githubusercontent.com/24228143/42137906-11b780a8-7d92-11e8-9f0f-d6abd3755191.jpeg)
